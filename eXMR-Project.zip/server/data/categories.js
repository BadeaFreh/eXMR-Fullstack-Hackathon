const CATEGORIES = [
    { name: "Pop", color: "#3b82f6" },
    { name: "Hip-Hop", color: "#16a34a" },
    { name: "Metal", color: "#ef4444" },
    { name: "Rock", color: "#eab308" },
    { name: "Country", color: "#db2777" },
    { name: "Soul", color: "#14b8a6" },
    { name: "Alternative", color: "#f97316" },
    { name: "Electronic", color: "#8b5cf6" },
    { name: "Rap", color: "#7149C6" },
    { name: "RNB", color: "#867070" },
  ];