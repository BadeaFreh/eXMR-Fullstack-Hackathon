const CONFIG = {
    DB_URL: "mongodb://127.0.0.1:27017/songsDB",
    PORT: 4200
}

module.exports = { CONFIG }